create function listar_alumnos()
  returns SETOF alumno
language sql
as $$
select *
    from alumno
	where codigo is not null and codigo<>'0';
$$;

