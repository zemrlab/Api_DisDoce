create function insert_usuario_perfil(id_usuario_in numeric)
  returns numeric
language plpgsql
as $$
DECLARE
  var_usuario_perfil INTEGER DEFAULT 0;
BEGIN
  var_usuario_perfil:=(select COUNT(*) from USUARIO_PERFIL WHERE id_usuario=id_usuario_in AND id_perfil=1);

    IF var_usuario_perfil = 0 THEN
      INSERT INTO USUARIO_PERFIL(id_usuario, id_perfil) VALUES(id_usuario_in, 1);
    END IF;

RETURN NULL;
END;
$$;

