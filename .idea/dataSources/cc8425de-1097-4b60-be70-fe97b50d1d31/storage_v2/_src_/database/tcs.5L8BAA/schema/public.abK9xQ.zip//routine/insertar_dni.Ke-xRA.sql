create function insertar_dni()
  returns trigger
language plpgsql
as $$
BEGIN

UPDATE alumno_programa
set dni = new.did_alumno
WHERE alumno_programa.cod_alumno = new.cod_alumno;

RETURN NULL;
END;
$$;

