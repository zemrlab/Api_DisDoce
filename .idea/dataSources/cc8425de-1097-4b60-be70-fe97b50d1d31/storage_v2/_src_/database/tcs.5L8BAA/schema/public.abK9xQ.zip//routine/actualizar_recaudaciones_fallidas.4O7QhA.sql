create function actualizar_recaudaciones_fallidas(id_registro_fun numeric, nombre_archivo_fun character varying, descripcion_error_fun character varying)
  returns numeric
language plpgsql
as $$
DECLARE
  llamar_funcion VARCHAR;
BEGIN
  
  UPDATE RECAUDACIONES_FALLIDAS SET id_registro = id_registro_fun WHERE nombre_archivo = nombre_archivo_fun AND descripcion_error = descripcion_error_fun;

RETURN NULL;
END;
$$;

