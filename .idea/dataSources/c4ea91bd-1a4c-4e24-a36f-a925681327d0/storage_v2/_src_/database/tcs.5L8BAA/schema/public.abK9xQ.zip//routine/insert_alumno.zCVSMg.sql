create function insert_alumno(id_usuario_alumno numeric, id_facultad_alumno numeric, ape_nom_alumno character varying, codido_alumno character)
  returns numeric
language plpgsql
as $$
DECLARE
	var_ape_nom INTEGER DEFAULT 0;
BEGIN
 	var_ape_nom:=(select COUNT(ape_nom) from ALUMNO WHERE ape_nom=ape_nom_alumno);

    IF var_ape_nom = 0 THEN
    	INSERT INTO ALUMNO(id_usuario, id_facultad, ape_nom, codigo) VALUES(id_usuario_alumno, id_facultad_alumno, ape_nom_alumno, codido_alumno);
  	END IF;

RETURN NULL;
END;
$$;

