create function duplicar()
  returns trigger
language plpgsql
as $$
DECLARE
	--variables
    var_id_usuario NUMERIC;
    var_id_facultad NUMERIC;

    var_id_alum NUMERIC;
    var_id_concepto NUMERIC;
    var_id_registro NUMERIC;

    llamar_funcion VARCHAR;
BEGIN
	llamar_funcion:=insert_facultad(NEW.dependencia); --llamada a la funci�n para insertar

    llamar_funcion:=insert_usuario(NEW.nombre); --llamada a la funci�n para insertar

    var_id_usuario:=(SELECT id_usuario FROM USUARIO WHERE user_name=NEW.nombre); --obtener id_usuario
    var_id_facultad:=(SELECT id_facultad FROM FACULTAD WHERE nombre=NEW.dependencia); --obtener id_facultad
    llamar_funcion:=insert_alumno(var_id_usuario, var_id_facultad, NEW.nombre, NEW.codigo); --llamada a la funci�n para insertar

    llamar_funcion:=insert_concepto(NEW.concep, NEW.concep_a, NEW.concep_b); --llamada a la funci�n para insertar

    var_id_alum:=(SELECT id_alum FROM ALUMNO WHERE ape_nom=NEW.nombre); --obtener id_alum
    var_id_concepto:=(SELECT id_concepto FROM CONCEPTO WHERE concepto=NEW.concep); --obtener id_concepto
    var_id_registro:=(SELECT id_registro FROM REGISTRO_CARGA ORDER BY id_registro DESC LIMIT 1); --obtener id_registro
    llamar_funcion:=insert_recaudaciones(var_id_alum, var_id_concepto, var_id_registro, NEW.moneda, NEW.numero, NEW.importe, NEW.carnet, NEW.autoseguro, NEW.ave, NEW.devol_tran, NEW.observacion); --llamada a la funci�n para insertar

    RETURN NULL;
END;
$$;

