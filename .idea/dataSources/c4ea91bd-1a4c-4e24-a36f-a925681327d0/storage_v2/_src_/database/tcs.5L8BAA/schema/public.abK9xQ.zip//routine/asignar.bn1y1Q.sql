create function asignar()
  returns trigger
language plpgsql
as $$
DECLARE
	--variables
    var_id_registro NUMERIC;

    llamar_funcion VARCHAR;
BEGIN
	var_id_registro:=(SELECT id_registro FROM REGISTRO_CARGA ORDER BY id_registro DESC LIMIT 1); --obtener id_registro

    llamar_funcion:=actualizar_recaudaciones_fallidas(var_id_registro, NEW.nombre_archivo, NEW.descripcion_error); --llamada a la funci�n para actualizar

    RETURN NULL;
END;
$$;

