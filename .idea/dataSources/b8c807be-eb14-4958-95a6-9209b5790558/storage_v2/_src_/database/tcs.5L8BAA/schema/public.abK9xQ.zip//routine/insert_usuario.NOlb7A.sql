create function insert_usuario(user_name_usuario character varying)
  returns numeric
language plpgsql
as $$
DECLARE
	var_user_name INTEGER DEFAULT 0;
BEGIN
 	var_user_name:=(select COUNT(user_name) from USUARIO WHERE user_name=user_name_usuario);

    IF var_user_name = 0 THEN
    	INSERT INTO USUARIO(id_TU, user_name, pass) VALUES(1,user_name_usuario,'');
  	END IF;

RETURN NULL;
END;
$$;

