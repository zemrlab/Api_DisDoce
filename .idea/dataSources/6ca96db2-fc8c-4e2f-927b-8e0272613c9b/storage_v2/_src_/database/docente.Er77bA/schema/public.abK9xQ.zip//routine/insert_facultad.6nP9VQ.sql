create function insert_facultad(nombre_facultad character varying)
  returns numeric
language plpgsql
as $$
DECLARE
	var_nombre INTEGER DEFAULT 0;
BEGIN
 	var_nombre:=(select COUNT(nombre) from FACULTAD WHERE nombre=nombre_facultad);
	
    IF var_nombre = 0 THEN
    	INSERT INTO FACULTAD(nombre) VALUES(nombre_facultad);
  	END IF;
    
RETURN NULL;
END;
$$;

