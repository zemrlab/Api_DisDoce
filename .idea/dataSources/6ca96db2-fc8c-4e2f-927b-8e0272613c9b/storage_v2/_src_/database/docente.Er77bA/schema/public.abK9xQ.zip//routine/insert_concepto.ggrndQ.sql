create function insert_concepto(concepto_concepto character, concep_a_concepto character, concep_b_concepto character)
  returns numeric
language plpgsql
as $$
DECLARE
	var_concepto INTEGER DEFAULT 0;
BEGIN
 	var_concepto:=(SELECT COUNT(concepto) FROM CONCEPTO WHERE concepto=concepto_concepto);
	
    IF var_concepto = 0 THEN
    	INSERT INTO CONCEPTO(concepto, concep_a, concep_b) VALUES(concepto_concepto, concep_a_concepto, concep_b_concepto);
  	END IF;
    
RETURN NULL;
END;
$$;

