create function insert_recaudaciones(id_alum_rec numeric, id_concepto_rec numeric, id_registro_rec numeric, moneda_rec character, numero_rec character varying, importe_rec money, carnet_rec character varying, autoseguro_rec character varying, ave_rec character varying, devol_tran_rec character varying, observacion_red character varying)
  returns numeric
language plpgsql
as $$
DECLARE
	var_numero INTEGER DEFAULT 0;
BEGIN
 	var_numero:=(SELECT COUNT(numero) FROM RECAUDACIONES WHERE numero=numero_rec);

    IF var_numero = 0 THEN
    	INSERT INTO RECAUDACIONES(
	id_alum, id_concepto, id_registro, moneda, numero, importe, carnet, autoseguro, ave, devol_tran, observacion)
	VALUES (id_alum_rec, id_concepto_rec, id_registro_rec, moneda_rec, numero_rec, importe_rec, carnet_rec, autoseguro_rec, ave_rec, devol_tran_rec, observacion_red);
    END IF;

RETURN NULL;
END;
$$;

